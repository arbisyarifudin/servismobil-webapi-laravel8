
<?php $__env->startSection('title', 'Data Pelanggan'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-11">
                <div class="card">
                    <div class="card-body">
                        <h2>Data Pelanggan</h2>
                        <hr>
                        <?php if(session('flash-success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('flash-success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('flash-danger')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('flash-danger')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th width="100">Foto</th>
                                        <th>Nama</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Jenis Kelamin</th>
                                        <th>No. Telp/HP</th>
                                        <th>Alamat</th>
                                        
                                        <th width="15%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td>
                                                <img src="<?php echo e($item->photo_url); ?>" alt="photo" class="img-fluid">
                                            </td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->username); ?></td>
                                            <td><?php echo e($item->email); ?></td>
                                            <td><?php echo e($item->gender == 'M' ? 'Laki-laki' : 'Perempuan'); ?></td>
                                            <td><?php echo e($item->phone ?? '-'); ?></td>
                                            <td><?php echo e($item->address ?? '-'); ?></td>
                                            
                                            <td>
                                                <a title="Detail" data-toggle="tooltip"
                                                    href="<?php echo e(url('customer/' . $item->id)); ?>"
                                                    class="btn btn-sm btn-success"><i class="fa fa-search"></i></a>
                                                <a title="Ubah" data-toggle="tooltip"
                                                    href="<?php echo e(url('customer/' . $item->id . '/edit')); ?>"
                                                    class="btn btn-sm btn-info"><i class="fa fa-edit"></i></a>
                                                <form action="<?php echo e(url('customer/' . $item->id)); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button title="Hapus" data-toggle="tooltip"
                                                        onclick="return confirm('Apakah anda yakin?')"
                                                        class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($customer) < 1): ?>
                                        <tr>
                                            <td colspan="9" class="text-center">Data kosong.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="<?php echo e(url('customer/create')); ?>" class="btn btn-primary"><span
                                    class="oi oi-plus"></span> Tambah </a>
                            <?php echo e($customer->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\project\ta\frezy\web\resources\views/customer/index.blade.php ENDPATH**/ ?>