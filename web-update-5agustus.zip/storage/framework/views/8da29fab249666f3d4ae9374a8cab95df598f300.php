

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-body">
                        <h2>Data Produk</h2>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Harga</th>
                                        <th>Kategori</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>$loop->iteration</td>
                                            <td>$item->name</td>
                                            <td>$item->price</td>
                                            <td>$item->category_id</td>
                                            <td>
                                                <a href="<?php echo e(url('product/edit/' . $item->id)); ?>"
                                                    class="btn btn-sm btn-info">Ubah</a>
                                                <form action="<?php echo e(url('product/delete/' . $item->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button onclick="return confirm('Apakah anda yakin?')"
                                                        class="btn btn-sm btn-danger">Hapus</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($product) < 1): ?>
                                        <tr>
                                            <td colspan="5" class="text-center">Data kosong.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <a href="<?php echo e(url('product/create')); ?>" class="btn btn-primary">Tambah Data</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\project\ta\frezy\web\resources\views/product/list.blade.php ENDPATH**/ ?>