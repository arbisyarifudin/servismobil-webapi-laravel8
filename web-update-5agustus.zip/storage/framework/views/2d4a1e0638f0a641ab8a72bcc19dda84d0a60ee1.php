
<?php $__env->startSection('title', 'Data Pembayaran'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-body">
                        <h2>Data Pembayaran</h2>
                        <hr>
                        <?php if(session('flash-success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('flash-success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('flash-danger')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('flash-danger')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>ID Servis</th>
                                        <th>Tagihan</th>
                                        <th>Pembayaran</th>
                                        <th>Kembalian</th>
                                        <th>Penanggungjawab</th>
                                        <th>Tanggal</th>
                                        <th width="150">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td># <?php echo e($item->service->id); ?></td>
                                            <td><?php echo e($item->bill); ?></td>
                                            <td><?php echo e($item->pay); ?></td>
                                            <td><?php echo e($item->change); ?></td>
                                            <td><?php echo e($item->admin->name); ?></td>
                                            <td><?php echo e(date('d/m/Y', strtotime($item->created_at))); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('payment/' . $item->id)); ?>"
                                                    class="btn btn-sm btn-success">Detail</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($payments) < 1): ?>
                                        <tr>
                                            <td colspan="5" class="text-center">Data kosong.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                
                                <a href="<?php echo e(url('reservation')); ?>" class="btn btn-primary btn-sm">
                                    <span class="oi oi-list mr-1"></span> Lihat Reservasi
                                </a>
                            </div>
                            <?php echo e($payments->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\project\ta\frezy\web\resources\views/payment/index.blade.php ENDPATH**/ ?>