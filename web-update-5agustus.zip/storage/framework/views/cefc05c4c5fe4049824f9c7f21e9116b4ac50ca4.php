
<?php $__env->startSection('title', 'Detail Pelanggan'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center mb-3">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h2>Detail Pelanggan / #<?php echo e($customer->id); ?></h2>
                        <hr>
                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="150">Nama</th>
                                    <td width="20">:</td>
                                    <td><?php echo e($customer->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td>:</td>
                                    <td><?php echo e($customer->email); ?></td>
                                </tr>
                                <tr>
                                    <th>Jenis Kelamin</th>
                                    <td>:</td>
                                    <td><?php echo e($customer->gender == 'M' ? 'Laki-laki' : 'Perempuan'); ?></td>
                                </tr>
                                <tr>
                                    <th>No. HP/Telp</th>
                                    <td>:</td>
                                    <td><?php echo e($customer->phone ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Alamat</th>
                                    <td>:</td>
                                    <td><?php echo e($customer->address ?? '-'); ?></td>
                                </tr>
                            </table>
                        </div>
                        <a href="<?php echo e(url('customer')); ?>" class="btn btn-secondary">Kembali</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <img src="<?php echo e($customer->photoUrl); ?>" alt="photo" class="img-fluid"
                            style="max-height: 350px; width: 100%; object-fit: contain;">
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <h3>Kendaraan Pelanggan</h3>
                            <hr>
                            <?php if(session('flash-success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('flash-success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('flash-danger')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('flash-danger')); ?>

                                </div>
                            <?php endif; ?>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kendaraan</th>
                                        <th>Brand/Merek</th>
                                        <th>Tahun</th>
                                        <th>Nomor Polisi</th>
                                        <th>Nomor Rangka</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->brand); ?></td>
                                            <td><?php echo e($item->year); ?></td>
                                            <td><?php echo e($item->plate_number); ?></td>
                                            <td><?php echo e($item->chassis_number); ?></td>
                                            <td>
                                                <a title="Ubah" data-toggle="tooltip"
                                                    href="<?php echo e(url('vehicle/' . $item->id . '/edit?ref_customer=' . $customer->id . '&ref=' . url()->current())); ?>"
                                                    class="btn btn-sm btn-info"><i class="fa fa-edit"></i></a>
                                                <form
                                                    action="<?php echo e(url('vehicle/' . $item->id . '?ref=' . url()->current())); ?>"
                                                    method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button title="Hapus" data-toggle="tooltip"
                                                        onclick="return confirm('Apakah anda yakin?')"
                                                        class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($vehicles) <= 0): ?>
                                        <tr>
                                            <td colspan="7" class="text-center">Data kendaraan pelanggan ini kosong.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <hr>
                            <a href="<?php echo e(url('vehicle/create?ref_customer=' . $customer->id . '&ref=' . url()->current())); ?>"
                                class="btn btn-primary"><i class="fa fa-plus"></i>
                                Tambah Kendaraan</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\project\ta\frezy\web\resources\views/customer/show.blade.php ENDPATH**/ ?>