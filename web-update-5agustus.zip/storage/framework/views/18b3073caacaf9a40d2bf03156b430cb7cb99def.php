
<?php $__env->startSection('title', 'Data Montir'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-body">
                        <h2>Data Montir</h2>
                        <hr>
                        <?php if(session('flash-success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('flash-success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('flash-danger')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('flash-danger')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th width="100">Foto</th>
                                        <th>Nama</th>
                                        <th>NIK</th>
                                        <th>Telp/HP</th>
                                        <th>Alamat</th>
                                        <th>Status</th>
                                        <th width="150">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $mechanic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    if($item->is_active == 1) {
                                        $label =  'success';
                                    } else {
                                        $label =  'secondary';
                                    }
                                    ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td>
                                                <img src="<?php echo e($item->photo_url); ?>" alt="photo" class="img-fluid">
                                            </td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->nin ?? '-'); ?></td>
                                            <td><?php echo e($item->phone ?? '-'); ?></td>
                                            <td><?php echo e($item->address ?? '-'); ?></td>
                                            <td>
                                                <span class="badge badge-<?php echo e($label); ?>">
                                                    <?php echo e($item->is_active == 1 ? "Aktif" : 'Tidak Aktif'); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('mechanic/' . $item->id . '/edit')); ?>"
                                                    class="btn btn-sm btn-info">Ubah</a>
                                                <form action="<?php echo e(url('mechanic/' . $item->id)); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button onclick="return confirm('Apakah anda yakin?')"
                                                        class="btn btn-sm btn-danger">Hapus</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($mechanic) < 1): ?>
                                        <tr>
                                            <td colspan="7" class="text-center">Data kosong.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                                <a href="<?php echo e(url('mechanic/create')); ?>" class="btn btn-primary"><span
                                        class="oi oi-plus"></span> Tambah </a>
                            <?php echo e($mechanic->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\project\ta\frezy\web\resources\views/mechanic/index.blade.php ENDPATH**/ ?>