<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- API Base URL -->
    <meta name="api-base-url" content="<?php echo e(url('api')); ?>" />

    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    

    <!-- Styles -->
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('font/css/open-iconic-bootstrap.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldPushContent('style'); ?>

</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <?php if(auth()->guard()->check()): ?>
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('home')); ?>">Dashboard</a>
                            </li>
                            <?php if(auth()->user() && auth()->user()->level == 'Manager'): ?>
                                <li class="nav-item dropdown">
                                    <a id="menuDropdown-1" class="nav-link dropdown-toggle" href="#" role="button"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        Tim Kerja
                                    </a>

                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="menuDropdown-1">
                                        <a class="dropdown-item" href="<?php echo e(url('admin')); ?>">
                                            Karyawan
                                        </a>
                                        <a class="dropdown-item" href="<?php echo e(url('mechanic')); ?>">
                                            Montir
                                        </a>
                                    </div>
                                </li>
                            <?php endif; ?>
                            <li class="nav-item dropdown">
                                <a id="menuDropdown-2" class="nav-link dropdown-toggle" href="#" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    Layanan
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="menuDropdown-2">
                                    <a class="dropdown-item" href="<?php echo e(url('package')); ?>">
                                        Paket
                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(url('product')); ?>">
                                        Produk
                                    </a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('customer')); ?>">Pelanggan</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('reservation')); ?>">Reservasi</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('payment')); ?>">Pembayaran</a>
                            </li>
                        </ul>
                    <?php endif; ?>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(url('profile')); ?>">
                                        Profil
                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                                                                                                                                                         document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    

    <?php echo $__env->yieldPushContent('script'); ?>

</body>

</html>
<?php /**PATH E:\wamp64\www\project\ta\frezy\web\resources\views/layouts/app.blade.php ENDPATH**/ ?>