
<?php $__env->startSection('title', 'Input Reservasi'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container" id="app">
        <div class="row justify-content-center mb-3">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-body">
                        <h2>Input Reservasi</h2>
                        <hr>
                        <form action="<?php echo e(url('reservation')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div>
                                <input-reservation />
                            </div>
                            <hr>
                            <button type="submit" class="btn btn-primary btn-block">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\project\ta\frezy\web\resources\views/reservation/create.blade.php ENDPATH**/ ?>