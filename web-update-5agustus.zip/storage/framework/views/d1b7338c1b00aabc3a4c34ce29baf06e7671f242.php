<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="cardd">
                    



                    <div class="cardd-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <h4 class="mb-4">Selamat datang, <?php echo e(Auth::user()->name); ?>!</h4>

                        <div class="row mb-4">
                            <div class="col-md-4">
                                <div class="card shadow-sm">
                                    <div class="card-header">
                                        <h6 class="mb-0">Total Paket Layanan</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between">
                                            <h4>Total</h4>
                                            <h3><?php echo e($tot_paket); ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card shadow-sm">
                                    <div class="card-header">
                                        <h6 class="mb-0">Total Customer</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between">
                                            <h4>Total</h4>
                                            <h3><?php echo e($tot_customer); ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card shadow-sm">
                                    <div class="card-header">
                                        <h6 class="mb-0">Total Pendapatan</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between">
                                            <h4>Rp</h4>
                                            <h3><?php echo e(number_format($tot_pendapatan, 0, ',', '.')); ?></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card shadow-sm mb-4 d-print-none">
                            <form action="" method="GET">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h5 class="mr-3 mb-0">Statistik</h5>
                                    <div class="row align-items-center" style="min-width: 80%">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-md-5">
                                            <select name="bulan" class="form-control">
                                                <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e($bulan_filter == $item->number ? 'selected' : ''); ?>

                                                        value="<?php echo e($item->number); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-5">
                                            <select name="tahun" class="form-control">
                                                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e($tahun_filter == $item->year ? 'selected' : ''); ?>

                                                        value="<?php echo e($item->year); ?>"><?php echo e($item->year); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col">
                                            <button type="submit" class="btn btn-primary "><i class="fas fa-search"></i>
                                                Filter</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div class="card-body">
                                <canvas id="statistik"></canvas>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        var bulan = <?= $bulan ?>;
        var reservasi = <?= $reservasi ?>;
        var servis = <?= $servis ?>;
        document.addEventListener("DOMContentLoaded", function() {
            var chartdata = {
                labels: bulan,
                datasets: [{
                        label: 'Total Reservasi',
                        backgroundColor: 'rgba(26, 187, 156, 0.4)',
                        borderColor: 'rgba(26, 187, 156, 0.7)',
                        hoverBackgroundColor: 'rgba(26, 187, 156, 0.6)',
                        hoverBorderColor: 'rgba(26, 187, 156, 1)',
                        lineTension: 0.2,
                        data: reservasi
                    },
                    {
                        label: 'Total Servis',
                        backgroundColor: 'rgba(255, 99, 132, 0.4)',
                        borderColor: 'rgba(255, 99, 132, 0.7)',
                        hoverBackgroundColor: 'rgba(255, 99, 132, 0.6)',
                        hoverBorderColor: 'rgba(255, 99, 132, 1)',
                        lineTension: 0.2,
                        data: servis
                    }
                ]
            };

            var ctx = $("#statistik");

            var barGraph = new Chart(ctx, {
                type: 'line',
                data: chartdata,
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                },
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\project\ta\frezy\web\resources\views/home.blade.php ENDPATH**/ ?>