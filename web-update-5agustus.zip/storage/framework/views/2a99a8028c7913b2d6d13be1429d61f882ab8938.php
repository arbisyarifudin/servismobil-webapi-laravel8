
<?php $__env->startSection('title', 'Detail Reservasi'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center mb-3">
            <div class="col-md-5 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h2>Detail Reservasi / #<?php echo e($reservation->id); ?> </h2>
                        <hr>
                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="150">Nama Pelanggan</th>
                                    <td width="20">:</td>
                                    <td><?php echo e($reservation->customer ? $reservation->customer->name : '?'); ?></td>
                                </tr>
                                <tr>
                                    <th>No. HP / Telp</th>
                                    <td>:</td>
                                    <td><?php echo e($reservation->customer ? $reservation->customer->phone : '?'); ?></td>
                                </tr>
                                <tr>
                                    <th>Kendaraan</th>
                                    <td>:</td>
                                    <td><?php echo $reservation->vehicle ? $reservation->vehicle->name . ' <br> <small><b>Nopol:</b> ' . $reservation->vehicle->plate_number . '</small>' : '?'; ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>Keluhan Kendaraan</th>
                                    <td>:</td>
                                    <td><?php echo e($reservation->vehicle_complaint); ?></td>
                                </tr>
                                <tr>
                                    <th>Tanggal Reservasi</th>
                                    <td>:</td>
                                    <td><?php echo e(date('d/m/Y', strtotime($reservation->reservation_date))); ?> -
                                        <?php echo e(date('H:i', strtotime($reservation->reservation_time))); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="<?php echo e(url('reservation')); ?>" class="btn btn-secondary">Kembali</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-7">
                <div class="card">
                    <div class="card-body">
                        <h2 class="d-flex justify-content-between">
                            Paket Layanan
                            <?php if($reservation->service->payment): ?>
                                <a href="<?php echo e(url('payment/' . $reservation->service->payment->id . '?reservation_id=' . $reservation->id)); ?>"
                                    class="btn btn-danger"><i class="fa fa-credit-card"></i> Detail Pembayaran</a>
                            <?php endif; ?>
                            
                        </h2>
                        <hr>
                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tr>
                                    <th>Paket Layanan</th>
                                    <td>:</td>
                                    <td><?php echo e($reservation->package ? $reservation->package->name : '?'); ?></td>
                                </tr>
                                <tr>
                                    <th>Harga Paket Layanan</th>
                                    <td>:</td>
                                    <td>Rp
                                        <b><?php echo e($reservation->package ? number_format($reservation->package->products->sum('price'), 0, ',', '.') : '?'); ?></b>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Produk/Komponen</th>
                                        <th>Harga</th>
                                    </tr>
                                </thead>
                                <?php if($reservation->package->products): ?>
                                    <tbody>
                                        <?php $__currentLoopData = $reservation->package->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td>
                                                    <div class="d-flex justify-content-between">
                                                        <span>Rp</span> <span><?php echo e($item->priceFormatted); ?></span>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th colspan="2">Total</th>
                                            <th>
                                                <div class="d-flex justify-content-between">
                                                    <span>Rp</span>
                                                    <span><?php echo e(number_format($reservation->package->products->sum('price'), 0, ',', '.')); ?></span>
                                                </div>
                                            </th>
                                        </tr>
                                    </tfoot>
                                <?php else: ?>
                                    <tbody>
                                        <tr>
                                            <td colspan="3" class="text-center">Kosong.</td>
                                        </tr>
                                    </tbody>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php if($reservation->service->status != 'Finish'): ?>
            <div class="card">
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <div class="card-body">
                            <h3>Servis</h3>
                            <hr>
                            
                            <form action="<?php echo e(url('payment/create')); ?>" method="GET">
                                
                                <input type="hidden" name="service_id" value="<?php echo e($reservation->service->id); ?>">
                                <input type="hidden" name="reservation_id" value="<?php echo e($reservation->id); ?>">
                                <div class="row">
                                    <div class="col-md-8 mb-3">
                                        <div class="row">
                                            <div class="col-6 mb-3">
                                                <label>Montir Servis</label>
                                                <select name="mechanic_id" class="form-control" required>
                                                    <option value="">--Pilih--</option>
                                                    <?php $__currentLoopData = $mechanics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php if($reservation->service->mechanic && $item->id == $reservation->service->mechanic->id): ?> selected <?php endif; ?>
                                                            value="<?php echo e($item->id); ?>">
                                                            <?php echo e($item->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-6 mb-3">
                                                <label>Biaya Servis</label>
                                                <input type="hidden" name="package_price"
                                                    value="<?php echo e($reservation->package->products->sum('price')); ?>">
                                                <input type="number" name="service_fee" class="form-control" value="50000"
                                                    required>
                                                
                                            </div>
                                            <div class="col-12 mb-3">
                                                <label>Catatan Tambahan <code>[opsional]</code></label>
                                                <textarea name="note" class="form-control"
                                                    placeholder="Masukkan catatan atau komponen servis tambahan jika ada.."><?php echo e($reservation->service->note); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="row">
                                            <div class="col-12 mb-3">
                                                <label>Tanggal Servis Lanjutan</label>
                                                <input type="date" name="next_service_date" class="form-control"
                                                    value="<?php echo e(date('Y-m-d', strtotime(date('Y-m-d') . '+ 1 month'))); ?>"
                                                    required>
                                            </div>
                                            
                                            <div class="col-12 mb-3">
                                                <label>&nbsp;</label>
                                                <button type="submit" class="btn btn-primary btn-block"><i
                                                        class="fa fa-credit-card mr-1"></i>
                                                    Lakukan Penagihan</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-4">

                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\project\ta\frezy\web\resources\views/reservation/show.blade.php ENDPATH**/ ?>