
<?php $__env->startSection('title', 'Data Reservasi'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h2>Data Reservasi</h2>
                        <hr>
                        <?php if(session('flash-success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('flash-success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('flash-danger')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('flash-danger')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="table-responsive" id="app">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Pelanggan</th>
                                        <th>Paket Layanan</th>
                                        <th width="120">Harga Paket</th>
                                        <th width="150">Kendaraan</th>
                                        <th>Keluhan</th>
                                        <th>Tanggal Reservasi</th>
                                        <th>Jam Reservasi</th>
                                        <th>Asal</th>
                                        <th>Status Servis</th>
                                        <th width="5%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $reservation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->customer ? $item->customer->name : '?'); ?></td>
                                            <td><?php echo e($item->package ? $item->package->name : '?'); ?></td>
                                            <td>
                                                <div class="d-flex justify-content-between">
                                                    <span>Rp</span>
                                                    <span><?php echo e($item->package->products ? number_format($item->package->products->sum('price'), 0, ',', '.') : ''); ?></span>
                                                </div>
                                            </td>
                                            <td><?php echo $item->vehicle ? $item->vehicle->name . ' <br> <small><b>Nopol:</b> ' . $item->vehicle->plate_number . '</small>' : '?'; ?>

                                            </td>
                                            <td><?php echo e($item->vehicle_complaint); ?></td>
                                            <td><?php echo e(date('d/m/Y', strtotime($item->reservation_date))); ?></td>
                                            <td><?php echo e(date('H:i', strtotime($item->reservation_time))); ?></td>
                                            <td><?php echo e($item->reservation_origin == 'Online' ? 'Aplikasi' : 'Manual'); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <?php
                                                        if ($item->service->status == 'Process') {
                                                            $badge = 'info';
                                                        } elseif ($item->service->status == 'Finish') {
                                                            $badge = 'success';
                                                        } else {
                                                            $badge = 'warning';
                                                        }
                                                    ?>
                                                    <span class="badge badge-pill badge-<?php echo e($badge); ?>">&nbsp;</span>
                                                    <?php if($item->service->status == 'Finish'): ?>
                                                        <span style="min-width: 50px" class="ml-2">Selesai</span>
                                                    <?php else: ?>
                                                        <form class="ml-2" style="min-width: 100px"
                                                            action="<?php echo e(url('service/' . $item->service->id . '/status?ref=reservation')); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('put'); ?>
                                                            <div>
                                                                <change-service-status :data="<?php echo e($item->service); ?>" />
                                                            </div>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                                <?php if($item->service->mechanic): ?>
                                                    <div class="small mt-1">
                                                        Montir: <?php echo e($item->service->mechanic->name); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a title="Detail" data-toggle="tooltip"
                                                    href="<?php echo e(url('reservation/' . $item->id)); ?>"
                                                    class="btn btn-sm btn-success"><i class="fa fa-search"></i></a>
                                                <?php if($item->service->payment): ?>
                                                    <a title="Pembayaran" data-toggle="tooltip"
                                                        href="<?php echo e(url('payment/' . $item->service->payment->id . '?reservation_id=' . $item->id)); ?>"
                                                        class="btn btn-sm btn-danger"><i class="fa fa-credit-card"></i></a>
                                                <?php endif; ?>
                                                
                                                
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($reservation) < 1): ?>
                                        <tr>
                                            <td colspan="11" class="text-center">Data kosong.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <a href="<?php echo e(url('reservation/create')); ?>" class="btn btn-primary"><span
                                        class="oi oi-plus"></span> Tambah </a>

                            </div>
                            <?php echo e($reservation->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\project\ta\frezy\web\resources\views/reservation/index.blade.php ENDPATH**/ ?>